-- MySQL dump 10.13  Distrib 5.7.14, for Linux (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(254) NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Product #1',507585),(2,'Product #2',1110594),(3,'Product #3',1672408),(4,'Product #4',1131663),(5,'Product #5',348633),(6,'Product #6',508523),(7,'Product #7',1409649),(8,'Product #8',763057),(9,'Product #9',821699),(10,'Product #10',897898),(11,'Product #11',1442430),(12,'Product #12',485696),(13,'Product #13',1117150),(14,'Product #14',1840757),(15,'Product #15',943011),(16,'Product #16',437814),(17,'Product #17',119599),(18,'Product #18',291097),(19,'Product #19',1986087),(20,'Product #20',1934165),(21,'Product #21',693687),(22,'Product #22',1020090),(23,'Product #23',267598),(24,'Product #24',1770794),(25,'Product #25',615543),(26,'Product #26',150139),(27,'Product #27',262120),(28,'Product #28',1176774),(29,'Product #29',795533),(30,'Product #30',830554),(31,'Product #31',1062723),(32,'Product #32',1302119),(33,'Product #33',1940148),(34,'Product #34',735130),(35,'Product #35',433781),(36,'Product #36',288780),(37,'Product #37',1242653),(38,'Product #38',1842431),(39,'Product #39',1050838),(40,'Product #40',64352),(41,'Product #41',740329),(42,'Product #42',493267),(43,'Product #43',549048),(44,'Product #44',1856479),(45,'Product #45',334024),(46,'Product #46',1491060),(47,'Product #47',294292),(48,'Product #48',452623),(49,'Product #49',1781157),(50,'Product #50',280379),(51,'Product #51',386787),(52,'Product #52',474844),(53,'Product #53',1299470),(54,'Product #54',653385),(55,'Product #55',245637),(56,'Product #56',1914013),(57,'Product #57',802525),(58,'Product #58',506757),(59,'Product #59',1090787),(60,'Product #60',1597058),(61,'Product #61',1336311),(62,'Product #62',153509),(63,'Product #63',899176),(64,'Product #64',1276459),(65,'Product #65',887640),(66,'Product #66',1331958),(67,'Product #67',1564240),(68,'Product #68',130292),(69,'Product #69',1174389),(70,'Product #70',615077),(71,'Product #71',193644),(72,'Product #72',1913718),(73,'Product #73',1107345),(74,'Product #74',741693),(75,'Product #75',1770196),(76,'Product #76',1440369),(77,'Product #77',232752),(78,'Product #78',64488),(79,'Product #79',1891992),(80,'Product #80',13909),(81,'Product #81',343868),(82,'Product #82',278779),(83,'Product #83',487753),(84,'Product #84',1642339),(85,'Product #85',931165),(86,'Product #86',732391),(87,'Product #87',1556351),(88,'Product #88',1732690),(89,'Product #89',1238149),(90,'Product #90',647138),(91,'Product #91',1329748),(92,'Product #92',574460),(93,'Product #93',799647),(94,'Product #94',228924),(95,'Product #95',1849920),(96,'Product #96',1686287),(97,'Product #97',1559883),(98,'Product #98',1414159),(99,'Product #99',1815580),(100,'Product #100',734271);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` int(11) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `browser_name` varchar(255) DEFAULT NULL,
  `browser_version` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `screen_height` int(11) DEFAULT NULL,
  `screen_width` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats`
--

LOCK TABLES `stats` WRITE;
/*!40000 ALTER TABLE `stats` DISABLE KEYS */;
INSERT INTO `stats` VALUES (1,1,'1','1','1',1,1,1,1),(2,1,'1','1','1',1,1,1,1),(3,1010,'1010','1010','1010',1010,1010,1010,1010),(4,1010,'1010','1010','1010',1010,1010,1010,1010),(5,1478304168,'Mac OS','Chrome','4',55.7497002,37.8771951,1920,1010),(6,1478305409,'Mac OS','Chrome','54',55.7496807,37.877289,NULL,1010),(7,1478305423,'Mac OS','Chrome','54',55.7497618,37.877096,NULL,1010),(8,1478305463,'Mac OS','Chrome','54',55.7497268,37.8771267,1010,1920),(9,1478315458,'Mac OS','Chrome','54',55.7497011,37.8771363,1010,1920),(10,1478315496,'Mac OS','Chrome','54',55.749758,37.8771222,1010,1920),(11,1478315510,'Mac OS','Chrome','54',55.7497258,37.8771025,1010,1920);
/*!40000 ALTER TABLE `stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(120) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `session` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_idx` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test','f9bc4280e084578cb6a46901512bb6f003ab8287','uu220sj2lbuncjt8973ih64ap6');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-06 17:53:36
